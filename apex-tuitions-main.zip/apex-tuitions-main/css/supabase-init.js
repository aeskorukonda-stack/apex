const SUPABASE_URL = "https://agxoxrtetmcfwbpzyypo.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFneG94cnRldG1jZndicHp5eXBvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODcxMjg2MDIsImV4cCI6MjEwMjcwNDYwMn0.ASD3Sv83YCdwQURKYsuORWgBnSj37vXlz7EIEMFC3u0";
const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

let ADMIN_SECRET_KEY = localStorage.getItem("apex_admin_pin") || "1985";
let currentUser = null, currentProfile = null, currentRole = null;

const CATEGORY_DATA = {
  "Academic": ["Mathematics", "English", "Science (Physics/Chemistry/Bio)", "Social Studies", "Computer Science / Coding", "Hindi", "Sanskrit", "Commerce (Accountancy/Economics)", "All Subjects (Grades 1-5)", "Others"],
  "Non-Academic": ["Abacus", "Art & Craft / Drawing", "Music (Vocal)", "Music (Keyboard/Guitar)", "Vedic Maths", "Public Speaking", "Creative Writing", "Foreign Languages", "Others"],
  "Competitive": ["SSC (CGL/CHSL)", "RRB (Railways)", "DSC / TET", "Civils / UPSC", "State PSC (Group 1/2)", "Banking (IBPS/SBI)", "NEET / JEE Foundation", "Others"],
  "Others": ["Others"]
};

function escapeHtml(val) {
  return String(val || "").replace(/[&<>"']/g, m => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;" })[m]);
}

function showMsg(id, text, isOk) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.className = "msg " + (isOk ? "success" : "error");
  el.classList.remove("hidden");
}

async function checkGlobalSession() {
  try {
    const { data: { session } } = await db.auth.getSession();
    const btnLogin = document.getElementById("navBtnLogin");
    const btnDash = document.getElementById("navDashboard");
    const btnLogout = document.getElementById("navLogout");
    const joinCta = document.getElementById("homeJoinCtaContainer");

    if (session && session.user) {
      currentUser = session.user;
      if (btnLogin) btnLogin.classList.add("hidden");
      if (btnDash) btnDash.classList.remove("hidden");
      if (btnLogout) btnLogout.classList.remove("hidden");
      if (joinCta) joinCta.classList.add("hidden");

      const { data: t } = await db.from("teachers").select("*").eq("id", currentUser.id).maybeSingle();
      if (t) { currentRole = "teacher"; currentProfile = t; return; }

      const { data: s } = await db.from("students").select("*").eq("id", currentUser.id).maybeSingle();
      if (s) { currentRole = "student"; currentProfile = s; return; }

      currentRole = null;
      currentProfile = null;
    } else {
      currentUser = null; currentProfile = null; currentRole = null;
      if (btnLogin) btnLogin.classList.remove("hidden");
      if (btnDash) btnDash.classList.add("hidden");
      if (btnLogout) btnLogout.classList.add("hidden");
      if (joinCta) joinCta.classList.remove("hidden");
    }
  } catch (e) {
    console.error("Session check error:", e);
  }
}

async function logoutUser() {
  await db.auth.signOut();
  window.location.href = "index.html";
}

let adminClickCount = 0, adminClickTimer = null;
function handleSecretMultiTap() {
  adminClickCount++;
  clearTimeout(adminClickTimer);
  if (adminClickCount >= 5) {
    adminClickCount = 0;
    promptAdminAccess();
  } else {
    adminClickTimer = setTimeout(() => { adminClickCount = 0; }, 2000);
  }
}

function promptAdminAccess() {
  const pin = prompt("🔐 Enter Admin Access Key:");
  if (pin === ADMIN_SECRET_KEY) {
    window.location.href = "admin.html";
  } else if (pin !== null) {
    alert("❌ Invalid Access Key.");
  }
}

window.addEventListener("keydown", function(e) {
  if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "a") {
    e.preventDefault();
    promptAdminAccess();
  }
});
